/**
 * Tennis Clicker Extension - Background Service Worker
 * Handles extension lifecycle and communication
 */

console.log('Tennis Clicker Extension: Background service worker loaded');

// Extension installation
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('Tennis Clicker Extension installed');
  } else if (details.reason === 'update') {
    console.log('Tennis Clicker Extension updated');
  }
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Background received message:', message);

  if (message.type === 'PERFORM_CLICK') {
    // Forward click request to active tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {
          type: 'EXECUTE_CLICK',
          clickType: message.clickType
        });
      }
    });
    sendResponse({ success: true });
  }

  return true; // Keep message channel open for async response
});

// Keep service worker alive
chrome.runtime.onConnect.addListener((port) => {
  console.log('Port connected:', port.name);
});
