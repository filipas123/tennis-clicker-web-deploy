/**
 * Tennis Clicker Extension - Popup Script
 */

// Update status on popup open
document.addEventListener('DOMContentLoaded', () => {
  updateStatus();
  
  // Set up button listeners
  document.getElementById('openWebApp').addEventListener('click', openWebApp);
  document.getElementById('testClick').addEventListener('click', testClick);
});

/**
 * Update extension status
 */
function updateStatus() {
  const extensionStatus = document.getElementById('extensionStatus');
  const webAppStatus = document.getElementById('webAppStatus');
  
  // Extension is always active if popup is open
  extensionStatus.textContent = '✅ Active';
  extensionStatus.className = 'status-value status-active';
  
  // Check if web app is open
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0] && tabs[0].url) {
      const url = tabs[0].url;
      if (url.includes('tennis-clicker') || url.includes('localhost:3000') || url.includes('manus.computer')) {
        webAppStatus.textContent = '✅ Connected';
        webAppStatus.className = 'status-value status-active';
      } else {
        webAppStatus.textContent = '⚪ Not detected';
        webAppStatus.className = 'status-value status-inactive';
      }
    }
  });
}

/**
 * Open Tennis Clicker web app
 */
function openWebApp() {
  // Try to find existing tab with Tennis Clicker
  chrome.tabs.query({}, (tabs) => {
    const existingTab = tabs.find(tab => 
      tab.url && (
        tab.url.includes('tennis-clicker') || 
        tab.url.includes('localhost:3000')
      )
    );
    
    if (existingTab) {
      // Switch to existing tab
      chrome.tabs.update(existingTab.id, { active: true });
      chrome.windows.update(existingTab.windowId, { focused: true });
    } else {
      // Open new tab
      chrome.tabs.create({ url: 'http://localhost:3000/app' });
    }
    
    window.close();
  });
}

/**
 * Test click functionality
 */
function testClick() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, {
        type: 'EXECUTE_CLICK',
        clickType: 'single'
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('Test click failed:', chrome.runtime.lastError);
          alert('Test click failed. Make sure you are on a webpage.');
        } else {
          alert('Test click performed successfully!');
        }
      });
    }
  });
}
