/**
 * Tennis Clicker Extension - Content Script
 * Handles auto-click functionality and communication with web app
 */

console.log('Tennis Clicker Extension: Content script loaded');

// Notify web app that extension is ready (with retries)
function notifyExtensionReady() {
  window.postMessage({
    type: 'TENNIS_CLICKER_EXTENSION_READY'
  }, '*');
  console.log('Tennis Clicker Extension: Sent READY message');
}

// Send ready message immediately
notifyExtensionReady();

// Retry every second for 10 seconds to ensure web app receives it
let retryCount = 0;
const retryInterval = setInterval(() => {
  retryCount++;
  notifyExtensionReady();
  if (retryCount >= 10) {
    clearInterval(retryInterval);
  }
}, 1000);

// Listen for click requests from web app
window.addEventListener('message', (event) => {
  // Only accept messages from same window
  if (event.source !== window) return;

  if (event.data.type === 'TENNIS_CLICKER_AUTO_CLICK') {
    const clickType = event.data.clickType || 'single';
    performClick(clickType);
  }
});

// Listen for click commands from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'EXECUTE_CLICK') {
    performClick(message.clickType);
    sendResponse({ success: true });
  }
  return true;
});

// Track current mouse position
let lastMouseX = window.innerWidth / 2;
let lastMouseY = window.innerHeight / 2;

// Update mouse position on every mouse move
document.addEventListener('mousemove', (e) => {
  lastMouseX = e.clientX;
  lastMouseY = e.clientY;
});

/**
 * Perform automated click at current mouse position
 * @param {string} clickType - 'single' or 'double'
 */
function performClick(clickType) {
  try {
    // Use last known mouse position
    const x = lastMouseX;
    const y = lastMouseY;

    // Get element at mouse position
    const element = document.elementFromPoint(x, y);
    
    if (!element) {
      throw new Error('No element found at mouse position');
    }

    // Create and dispatch mouse events at exact mouse position
    const mouseDownEvent = new MouseEvent('mousedown', {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y,
      button: 0
    });
    
    const mouseUpEvent = new MouseEvent('mouseup', {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y,
      button: 0
    });
    
    const clickEvent = new MouseEvent('click', {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y,
      button: 0
    });

    if (clickType === 'double') {
      // Double click with full event sequence
      element.dispatchEvent(mouseDownEvent);
      element.dispatchEvent(mouseUpEvent);
      element.dispatchEvent(clickEvent);
      
      setTimeout(() => {
        element.dispatchEvent(mouseDownEvent);
        element.dispatchEvent(mouseUpEvent);
        element.dispatchEvent(clickEvent);
        notifyClickPerformed('double', true);
      }, 50);
    } else {
      // Single click with full event sequence
      element.dispatchEvent(mouseDownEvent);
      element.dispatchEvent(mouseUpEvent);
      element.dispatchEvent(clickEvent);
      notifyClickPerformed('single', true);
    }

    console.log(`Tennis Clicker: Performed ${clickType} click`);
  } catch (error) {
    console.error('Tennis Clicker: Click failed:', error);
    notifyClickPerformed(clickType, false, error.message);
  }
}

/**
 * Notify web app that click was performed
 * @param {string} clickType - Type of click
 * @param {boolean} success - Whether click succeeded
 * @param {string} error - Error message if failed
 */
function notifyClickPerformed(clickType, success, error = null) {
  window.postMessage({
    type: 'TENNIS_CLICKER_CLICK_PERFORMED',
    clickType,
    success,
    error
  }, '*');
}

// Periodic heartbeat to keep connection alive
setInterval(() => {
  window.postMessage({
    type: 'TENNIS_CLICKER_EXTENSION_HEARTBEAT'
  }, '*');
}, 30000); // Every 30 seconds
