# Tennis Clicker Browser Extension

This browser extension enables automated clicking functionality for the Tennis Clicker web application.

## Features

- **Auto-Click**: Automatically performs clicks when tennis players score points
- **Click Types**: Supports both single and double clicks
- **Seamless Integration**: Communicates with the Tennis Clicker web app via message passing
- **Lightweight**: Minimal resource usage with efficient event handling
- **Cross-Browser**: Compatible with Chrome, Edge, and other Chromium-based browsers

## Installation

### For Chrome/Edge

1. Open your browser and navigate to:
   - **Chrome**: `chrome://extensions/`
   - **Edge**: `edge://extensions/`

2. Enable **Developer mode** (toggle in the top right corner)

3. Click **Load unpacked**

4. Select the `extension` folder from this project

5. The Tennis Clicker extension icon should appear in your browser toolbar

### For Firefox

Firefox support requires converting to Manifest V2. A Firefox-compatible version will be provided separately.

## Usage

1. **Install the extension** following the instructions above

2. **Open the Tennis Clicker web app** at your deployed URL or `http://localhost:3000/app`

3. **Connect to your WebSocket server** in the web app

4. **Subscribe to a live tennis match**

5. **Configure your auto-click settings**:
   - Choose click filter (All points / P1 only / P2 only)
   - Select click type (Single / Double)

6. **Auto-clicks will happen automatically** when points are scored!

## Extension Popup

Click the extension icon to access:

- **Status Display**: Shows extension and web app connection status
- **Quick Launch**: Button to open the Tennis Clicker web app
- **Test Click**: Test the auto-click functionality

## How It Works

1. **Content Script** (`content.js`): Injected into all web pages, listens for click requests from the web app

2. **Background Service Worker** (`background.js`): Manages extension lifecycle and message routing

3. **Message Passing**: Web app sends click requests via `window.postMessage()`, extension performs the click

4. **Click Execution**: Simulates mouse click events at the current cursor position

## Permissions

- `activeTab`: Required to interact with the current tab
- `scripting`: Required to inject content scripts
- `<all_urls>`: Required to work on any website where you need auto-click

## Development

### File Structure

```
extension/
├── manifest.json           # Extension configuration
├── popup.html             # Extension popup interface
├── scripts/
│   ├── background.js      # Background service worker
│   ├── content.js         # Content script for auto-click
│   └── popup.js           # Popup functionality
├── icons/
│   ├── icon16.png         # 16x16 icon
│   ├── icon48.png         # 48x48 icon
│   └── icon128.png        # 128x128 icon
└── README.md              # This file
```

### Testing

1. Load the extension in developer mode
2. Open the Tennis Clicker web app
3. Check the browser console for extension messages
4. Use the "Test Click" button in the extension popup

## Troubleshooting

**Extension not working?**
- Make sure Developer mode is enabled
- Check that the extension is loaded and active
- Reload the extension after making changes
- Check the browser console for error messages

**Web app not detecting extension?**
- Refresh the web app page
- Check that you're on the correct URL
- Look for "Extension connected" message in the activity log

**Clicks not happening?**
- Ensure you're subscribed to a live match
- Check that your click filter settings match the point winner
- Verify the extension has permission to access the current page

## Publishing

To publish to the Chrome Web Store:

1. Create a ZIP file of the `extension` folder
2. Go to [Chrome Web Store Developer Dashboard](https://chrome.google.com/webstore/devconsole)
3. Upload the ZIP file
4. Fill in the required metadata
5. Submit for review

## License

MIT License - Created by @zeddd_365

## Support

For issues or questions, please refer to the main Tennis Clicker documentation.
